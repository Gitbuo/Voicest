# Voicest v1.7

Trình tổng hợp giọng hát kiểu UTAU chạy hoàn toàn trên trình duyệt (`public/voicest.html`), kèm vỏ React/Vite hiển thị biểu đồ đường cong F0 ở thanh dưới.

## Chạy

```
npm install
npm run dev      # http://localhost:3000
npm test         # 29 test cho src/lib
npm run build
```

`public/voicest.html` chạy độc lập được (mở trực tiếp bằng trình duyệt).

## Có gì mới ở v1.7

- Bỏ panel alias chi tiết, ô Reclist và biểu đồ nguyên âm; thêm Gender (formant) và Hơi thở đầu âm (~100ms).
- Tần số lấy mẫu thêm 48 / 88.2 / 96 / 192 kHz.
- Cọ tunning = Cọ + Tune tự do (phím 3).
- Nút Ảnh nền bật/tắt ảnh nhân vật của track.
- Theo nốt khi phát: lia vào giữa + nốt nảy.

## Có gì mới ở v1.6

- Sửa lỗi voicebank UTAU không render (biến `tl` bị dùng nhầm khiến phần đuôi nhả âm sập).
- Sửa bridge với shell React bị lọt vào thẻ `text/plain` nên không chạy.
- Auto-tune đọc `.frq` của voicebank, chạy ngầm; lần đầu tune toàn bộ, các lần sau chỉ tune nốt vừa sửa và hai nốt kề.
- Waveform thật nằm dưới nốt trong piano roll (không còn waveform giả trong biểu đồ F0).
- Bỏ thanh trên cùng; chức năng chuyển xuống hàng Dụng cụ; nút README (credit + phím tắt) ở góc trên.
- Bỏ toàn bộ icon, thống nhất chủ đề xanh bạc hà + hồng bông gòn.
- Chống chồng nốt ẩn khỏi màn hình nhưng vẫn chạy ngầm.

## Credit

| Thành phần | Tác giả |
|---|---|
| Resampler: World.JS v0.1.15 (WORLD vocoder: Masanori Morise) | YuzukiTsuru |
| Resampler: straycat-rs | UtaUtaUtau |
| Wavtool: Organum 0.0.8 | KakouLabs · KYURAE KIM (MIT) |
| Phonemizer: EN2JA+ (nay gộp vào "En to Ja" của OpenUtau) | Cadlaxa |
| Contributors | Gemini · LazioP · Claude |
