/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type Language = 'vi' | 'en' | 'ja' | 'zh' | 'ko';

export interface LanguageOption {
  code: Language;
  name: string;
  nativeName: string;
  shortLabel: string;
}

export const SUPPORTED_LANGUAGES: LanguageOption[] = [
  { code: 'vi', name: 'Vietnamese', nativeName: 'Tiếng Việt', shortLabel: 'VI' },
  { code: 'en', name: 'English', nativeName: 'English', shortLabel: 'EN' },
  { code: 'ja', name: 'Japanese', nativeName: '日本語', shortLabel: 'JA' },
  { code: 'zh', name: 'Chinese', nativeName: '中文', shortLabel: 'ZH' },
  { code: 'ko', name: 'Korean', nativeName: '한국어', shortLabel: 'KO' },
];

export const TRANSLATIONS: Record<Language, Record<string, string>> = {
  vi: {
    // Brand & Header
    app_title: 'VOICEST v1.5x',
    engine_badge: 'WebTau + Organum Wavtool',
    minimal_mode: 'Chế độ tối giản',

    // Quantize Controls
    quantize_btn: 'Quantize (Q)',
    quantize_tooltip: 'Căn lưới các nốt nhạc theo nhịp đã chọn (Phím tắt: Q)',
    legato_link_btn: 'Nối Legato',
    legato_link_tooltip: 'Khép các khoảng hở giữa nốt liền kề để chuyển âm mượt mà không vấp',
    auto_quantize: 'Tự động căn',
    auto_quantize_on: 'Bật',
    auto_quantize_off: 'Tắt',
    auto_quantize_tooltip: 'Tự động hút nốt theo lưới nhịp và khép khoảng hở khi vẽ nốt mới',
    grid_label: 'Lưới nhịp',
    grid_1_16: '1/16 (Chuẩn)',
    grid_1_8: '1/8 (Chậm)',
    grid_1_4: '1/4 (Nhịp lớn)',
    grid_1_32: '1/32 (Nhanh)',
    grid_1_64: '1/64 (Rất nhanh)',
    grid_1_16t: '1/16T (Liên 3)',
    grid_1_8t: '1/8T (Liên 3 chậm)',

    // Header Actions
    visualizer_toggle: 'Đường cong F0',
    visualizer_tooltip: 'Bật/tắt biểu đồ D3.js hiển thị đường cong cao độ',
    info_btn: 'Nâng cấp & Kỹ thuật',
    info_tooltip: 'Xem kiến trúc WebTau, Auto-Quantize, Straycat & Rust-WORLD',
    shortcuts_btn: 'Phím tắt',
    shortcuts_tooltip: 'Xem danh sách phím tắt thao tác nhanh',
    download_btn: 'Tải Voicest.html',
    download_tooltip: 'Tải file HTML Voicest chạy offline độc lập mọi lúc mọi nơi',
    reload_tooltip: 'Tải lại giao diện phòng thu',
    fullscreen_on: 'Toàn màn hình',
    fullscreen_off: 'Thu nhỏ màn hình',
    lang_selector: 'Ngôn ngữ',

    // Pitch Visualizer
    pitch_visualizer_title: 'Đường cong cao độ D3.js (Pitch F0 Contour)',
    track_vocal: 'Track Vocal',
    pitch_axis_label: 'Cao độ (MIDI Pitch)',
    time_axis_label: 'Thời gian (Giây)',
    total_notes: 'Tổng nốt',
    total_duration: 'Thời lượng',
    legato_transitions: 'Đoạn Legato S-Curve',
    avg_pitch: 'Pitch trung bình',
    zoom_in: 'Phóng to',
    zoom_out: 'Thu nhỏ',
    fit_zoom: 'Vừa khung',
    click_to_seek: 'Nhấp để tua phát lại tại đây',
    legato_badge: '50ms S-Curve Cosine',
    transition_tooltip: 'Chuyển âm Legato: {0} ➔ {1} ({2}ms)',
    note_tooltip: 'Nốt: {0} ({1}) | {2}s - {3}s ({4}s)',

    // Modals
    close: 'Đóng',
    understood: 'Đã hiểu',
    modal_title_info: 'Kiến trúc Nâng cấp Voicest',
    modal_subtitle_info: 'Tích hợp động cơ WebTau, Auto-Quantize, kiến trúc Straycat và Rust-WORLD',
    modal_title_shortcuts: 'Danh sách phím tắt tiện ích',

    // Technical descriptions
    tech_quantize_title: '1. Auto-Quantize & Triệt tiêu khoảng hở (Micro-Gap Elimination)',
    tech_quantize_desc: 'Hệ thống tự động căn chỉnh vị trí bắt đầu và độ dài nốt theo độ phân giải lưới được chọn (1/16, 1/8, 1/4, 1/32, 1/64, liên 3). Các vi khoảng hở giữa các nốt gần nhau sẽ được tự động nối liền để tránh vấp nhịp.',
    tech_legato_title: '2. Tự động nối Legato 50ms S-Curve (Chuẩn OpenUTAU / WebTau)',
    tech_legato_desc: 'Loại bỏ cơ chế nối cao độ thô. Các nốt liền kề tự động lướt cao độ đối xứng 50ms (±25ms quanh biên nốt) theo đường cong cosine S-curve mượt mà.',
    tech_straycat_title: '3. Kiến trúc Flags & Phân tích âm vị Straycat-rs',
    tech_straycat_desc: 'Hệ thống hỗ trợ phân tích cờ UTAU chuẩn (g: gender formant shift, B: breathiness, t: pitch mod, vel: velocity, p: compressor). Căn chỉnh preutterance và overlap chính xác theo oto.ini.',
    tech_rustworld_title: '4. DSP Vocoder Rust-WORLD (Soft Limiter & DC Blocker)',
    tech_rustworld_desc: 'Bổ sung bộ lọc DC blocker (15Hz highpass) và saturation limiter hàm tanh ngăn ngừa hiện tượng vỡ âm (digital clipping) khi tổng hợp các hòa âm nguyên âm.',
    tech_d3_title: '5. Trực quan hóa D3.js đường cong cao độ thời gian thực',
    tech_d3_desc: 'Hiển thị chính xác F0 contour thời gian thực, đánh dấu các vùng nối legato và playhead đồng bộ với thanh phát của studio.',

    // Shortcuts modal
    sc_space: 'Phát / Tạm dừng âm thanh',
    sc_q: 'Căn lưới các nốt (Quantize)',
    sc_tools: 'Chọn công cụ (1: Nốt, 2: Điểm tune, 3: Cọ tune, 4: Xóa)',
    sc_undo: 'Hoàn tác thay đổi',
    sc_redo: 'Làm lại thay đổi',
    sc_transpose: 'Dịch cao độ nửa cung (Giữ Shift để dịch quãng tám)',
    sc_home: 'Quay về đầu bản nhạc',
    sc_note_len: 'Tăng / Giảm độ dài nốt mặc định',
    sc_loop: 'Bật / Tắt chế độ lặp',
    sc_metro: 'Bật / Tắt máy gõ nhịp',

    // Feedback messages
    toast_quantized: 'Đã căn lưới {0} nốt theo lưới {1}!',
    toast_legato_done: 'Đã nối liền {0} đoạn legato hoàn hảo!',
    toast_lang_changed: 'Đã chuyển ngôn ngữ sang {0}',
  },
  en: {
    // Brand & Header
    app_title: 'VOICEST v1.5x',
    engine_badge: 'WebTau + Organum Wavtool',
    minimal_mode: 'Minimal Mode',

    // Quantize Controls
    quantize_btn: 'Quantize (Q)',
    quantize_tooltip: 'Quantize notes to current grid step (Shortcut: Q)',
    legato_link_btn: 'Link Legato',
    legato_link_tooltip: 'Close micro-gaps between adjacent notes for seamless legato transitions',
    auto_quantize: 'Auto-Snap',
    auto_quantize_on: 'ON',
    auto_quantize_off: 'OFF',
    auto_quantize_tooltip: 'Automatically snap notes to grid and close gaps while drawing',
    grid_label: 'Grid',
    grid_1_16: '1/16 (Standard)',
    grid_1_8: '1/8 (Slow)',
    grid_1_4: '1/4 (Beat)',
    grid_1_32: '1/32 (Fast)',
    grid_1_64: '1/64 (Ultra Fast)',
    grid_1_16t: '1/16T (Triplet)',
    grid_1_8t: '1/8T (Triplet Slow)',

    // Header Actions
    visualizer_toggle: 'F0 Curve',
    visualizer_tooltip: 'Toggle D3.js real-time pitch contour visualization',
    info_btn: 'Upgrades & Tech',
    info_tooltip: 'View WebTau, Auto-Quantize, Straycat & Rust-WORLD architecture',
    shortcuts_btn: 'Shortcuts',
    shortcuts_tooltip: 'View keyboard shortcuts guide',
    download_btn: 'Download HTML',
    download_tooltip: 'Download standalone offline Voicest HTML studio',
    reload_tooltip: 'Reload studio engine',
    fullscreen_on: 'Fullscreen',
    fullscreen_off: 'Exit Fullscreen',
    lang_selector: 'Language',

    // Pitch Visualizer
    pitch_visualizer_title: 'D3.js Pitch F0 Contour Visualizer',
    track_vocal: 'Vocal Track',
    pitch_axis_label: 'MIDI Pitch',
    time_axis_label: 'Time (Seconds)',
    total_notes: 'Total Notes',
    total_duration: 'Duration',
    legato_transitions: 'Legato S-Curves',
    avg_pitch: 'Average Pitch',
    zoom_in: 'Zoom In',
    zoom_out: 'Zoom Out',
    fit_zoom: 'Fit View',
    click_to_seek: 'Click to seek playback here',
    legato_badge: '50ms S-Curve Cosine',
    transition_tooltip: 'Legato Transition: {0} ➔ {1} ({2}ms)',
    note_tooltip: 'Note: {0} ({1}) | {2}s - {3}s ({4}s)',

    // Modals
    close: 'Close',
    understood: 'Got It',
    modal_title_info: 'Voicest Architectural Upgrades',
    modal_subtitle_info: 'WebTau Engine, Auto-Quantize, Straycat-rs & Rust-WORLD Vocoder DSP',
    modal_title_shortcuts: 'Keyboard Shortcuts Guide',

    // Technical descriptions
    tech_quantize_title: '1. Auto-Quantize & Micro-Gap Elimination',
    tech_quantize_desc: 'Automatically quantizes note onsets and lengths according to selected grid resolution (1/16, 1/8, 1/4, 1/32, 1/64, triplets). Seamlessly bridges micro-gaps to eliminate phasing jitter and rhythm lag in fast passages.',
    tech_legato_title: '2. 50ms S-Curve Legato Blending (OpenUTAU / WebTau standard)',
    tech_legato_desc: 'Replaces rigid manual pitch blending with continuous symmetrical 50ms cosine S-curve pitch glide centered at note boundaries.',
    tech_straycat_title: '3. Straycat-rs UTAU Flags & Phoneme Model',
    tech_straycat_desc: 'Modular parser for UTAU flags (g: gender/formants, B: breathiness, t: pitch mod, vel: consonant speed, p: peak compressor). Preutterance and overlap parameters are strictly compensated.',
    tech_rustworld_title: '4. Rust-WORLD Vocoder DSP (Limiter & DC Blocker)',
    tech_rustworld_desc: 'Integrated 15Hz DC blocker high-pass filter and tanh soft saturation limiter to eliminate clicks and prevent digital clipping during multi-harmonic vowel synthesis.',
    tech_d3_title: '5. Real-Time D3.js Vocal Pitch Contour',
    tech_d3_desc: 'Inspect synthesized vocal pitch glide in real-time with responsive playhead tracking and legato transition zones.',

    // Shortcuts modal
    sc_space: 'Play / Pause audio',
    sc_q: 'Quantize notes to grid',
    sc_tools: 'Select tool (1: Note, 2: Pitch points, 3: Brush, 4: Erase)',
    sc_undo: 'Undo edit',
    sc_redo: 'Redo edit',
    sc_transpose: 'Transpose semitone (Shift for octave)',
    sc_home: 'Jump to beginning',
    sc_note_len: 'Increase / Decrease default note length',
    sc_loop: 'Toggle loop playback',
    sc_metro: 'Toggle metronome',

    // Feedback messages
    toast_quantized: 'Quantized {0} notes to {1} grid!',
    toast_legato_done: 'Linked {0} legato transitions perfectly!',
    toast_lang_changed: 'Language switched to {0}',
  },
  ja: {
    // Brand & Header
    app_title: 'VOICEST v1.5x',
    engine_badge: 'WebTau エンジン + 自動レガート',
    minimal_mode: 'ミニマルモード',

    // Quantize Controls
    quantize_btn: 'クオンタイズ (Q)',
    quantize_tooltip: '選択したグリッドに合わせてノートを自動吸附 (ショートカット: Q)',
    legato_link_btn: 'レガート接続',
    legato_link_tooltip: '隣接ノート間の微小な隙間を塞ぎ、途切れのない滑らかなポルタメントを実現',
    auto_quantize: '自動吸着',
    auto_quantize_on: 'ON',
    auto_quantize_off: 'OFF',
    auto_quantize_tooltip: 'ノート入力時に自動でグリッド吸着とレガート隙間補正を実行',
    grid_label: 'グリッド',
    grid_1_16: '1/16 (標準)',
    grid_1_8: '1/8 (ゆったり)',
    grid_1_4: '1/4 (拍)',
    grid_1_32: '1/32 (高速)',
    grid_1_64: '1/64 (超高速)',
    grid_1_16t: '1/16T (3連符)',
    grid_1_8t: '1/8T (3連符長)',

    // Header Actions
    visualizer_toggle: 'F0ピッチ曲線',
    visualizer_tooltip: 'D3.js リアルタイムピッチ曲線の表示/非表示を切り替え',
    info_btn: '機能解説 & 技術',
    info_tooltip: 'WebTau、自動クオンタイズ、Straycat & Rust-WORLDアーキテクチャを表示',
    shortcuts_btn: 'ショートカット',
    shortcuts_tooltip: 'キーボードショートカット一覧を表示',
    download_btn: 'HTMLを保存',
    download_tooltip: 'オフラインで完全動作するVoicest HTMLをダウンロード',
    reload_tooltip: 'スタジオを再読み込み',
    fullscreen_on: '全画面表示',
    fullscreen_off: '全画面解除',
    lang_selector: '言語',

    // Pitch Visualizer
    pitch_visualizer_title: 'D3.js ピッチF0曲線ビジュアライザー',
    track_vocal: 'ボーカルトラック',
    pitch_axis_label: '音高 (MIDI Pitch)',
    time_axis_label: '時間 (秒)',
    total_notes: '総ノート数',
    total_duration: '再生時間',
    legato_transitions: 'レガート遷移区間',
    avg_pitch: '平均ピッチ',
    zoom_in: '拡大',
    zoom_out: '縮小',
    fit_zoom: '全体表示',
    click_to_seek: 'クリックしてシーク',
    legato_badge: '50ms S字コサインカーブ',
    transition_tooltip: 'レガート遷移: {0} ➔ {1} ({2}ms)',
    note_tooltip: 'ノート: {0} ({1}) | {2}秒 - {3}秒 ({4}秒)',

    // Modals
    close: '閉じる',
    understood: '了解',
    modal_title_info: 'Voicest アーキテクチャ強化',
    modal_subtitle_info: 'WebTauエンジン、自動クオンタイズ、Straycat & Rust-WORLD DSP統合',
    modal_title_shortcuts: 'ショートカット一覧',

    // Technical descriptions
    tech_quantize_title: '1. 自動クオンタイズ & 微小ギャップ除去',
    tech_quantize_desc: '指定したグリッド（1/16、1/8、1/4、1/32、3連符）にノートの開始位置と長さを自動補正。隣接ノート間の微細な隙間を自動で埋めて音の途切れを防ぎます。',
    tech_legato_title: '2. 50ms S字コサイン曲線の滑らかなレガート接続 (OpenUTAU準拠)',
    tech_legato_desc: '旧式の標準ピッチブレンドを撤廃。ノート境界前後25ms（合計50ms）にわたりWebTau標準の余弦波Sカーブでシームレスに周波数を遷移させます。',
    tech_straycat_title: '3. Straycat-rs フラグ解析 & 音素タイミングモデル',
    tech_straycat_desc: 'UTAU規格のフラグ（g: フォルマント・ジェンダー、B: 息成分、t: ピッチ微調、vel: 子音速度）のパースとoto.ini先行発声・オーバーラップ補正を実装。',
    tech_rustworld_title: '4. Rust-WORLD ボコーダーDSP (リミッター & DC除去)',
    tech_rustworld_desc: 'DCブロッカー（15Hzハイパス）とtanhソフトサチュレーションリミッターにより、母音合成時のクリッピングノイズやクリック音を根本的に防止。',
    tech_d3_title: '5. D3.js リアルタイム・ボーカルピッチ曲線',
    tech_d3_desc: '合成された歌声のF0周波数をD3.jsで描画。再生ヘッドと同期し、レガート接続の滑らかさを視覚的に確認できます。',

    // Shortcuts modal
    sc_space: '再生 / 停止',
    sc_q: 'グリッドに合わせてクオンタイズ',
    sc_tools: 'ツール選択 (1: ノート, 2: ピッチ点, 3: ブラシ, 4: 削除)',
    sc_undo: '元に戻す',
    sc_redo: 'やり直し',
    sc_transpose: '半音移調 (Shiftキーで1オクターブ)',
    sc_home: '先頭に戻る',
    sc_note_len: 'デフォルトノート長の増減',
    sc_loop: 'ループ再生の切り替え',
    sc_metro: 'メトロノームの切り替え',

    // Feedback messages
    toast_quantized: '{0}個のノートを{1}グリッドに整列しました！',
    toast_legato_done: '{0}箇所のレガート接続を最適化しました！',
    toast_lang_changed: '言語を{0}に切り替えました',
  },
  zh: {
    // Brand & Header
    app_title: 'VOICEST v1.5x',
    engine_badge: 'WebTau 引擎 + 自动连音',
    minimal_mode: '极简模式',

    // Quantize Controls
    quantize_btn: '量化 (Q)',
    quantize_tooltip: '按照所选节拍网格量化对齐音符 (快捷键: Q)',
    legato_link_btn: '连音连接',
    legato_link_tooltip: '消除相邻音符间的微小缝隙，实现自然无断裂的滑音',
    auto_quantize: '自动吸附',
    auto_quantize_on: '开启',
    auto_quantize_off: '关闭',
    auto_quantize_tooltip: '绘制音符时自动吸附网格并闭合连音微隙',
    grid_label: '网格',
    grid_1_16: '1/16 (标准)',
    grid_1_8: '1/8 (慢速)',
    grid_1_4: '1/4 (主拍)',
    grid_1_32: '1/32 (快速)',
    grid_1_64: '1/64 (极速)',
    grid_1_16t: '1/16T (三连音)',
    grid_1_8t: '1/8T (三连音慢)',

    // Header Actions
    visualizer_toggle: 'F0音高曲线',
    visualizer_tooltip: '开启/关闭 D3.js 实时音高曲线可视化',
    info_btn: '升级与技术架构',
    info_tooltip: '查看 WebTau 引擎、自动量化、Straycat 与 Rust-WORLD 架构',
    shortcuts_btn: '快捷键',
    shortcuts_tooltip: '查看键盘快捷键指南',
    download_btn: '下载 HTML',
    download_tooltip: '下载完全离线运行的 Voicest 单文件工作室',
    reload_tooltip: '重新加载工作室',
    fullscreen_on: '全屏模式',
    fullscreen_off: '退出全屏',
    lang_selector: '语言',

    // Pitch Visualizer
    pitch_visualizer_title: 'D3.js 音高 F0 曲线可视化',
    track_vocal: '人声音轨',
    pitch_axis_label: '音高 (MIDI Pitch)',
    time_axis_label: '时间 (秒)',
    total_notes: '总音符数',
    total_duration: '时长',
    legato_transitions: 'S型连音区间',
    avg_pitch: '平均音高',
    zoom_in: '放大',
    zoom_out: '缩小',
    fit_zoom: '适应全屏',
    click_to_seek: '单击此处跳转播放',
    legato_badge: '50ms 余弦 S 曲线',
    transition_tooltip: '连音过渡: {0} ➔ {1} ({2}ms)',
    note_tooltip: '音符: {0} ({1}) | {2}s - {3}s ({4}s)',

    // Modals
    close: '关闭',
    understood: '了解',
    modal_title_info: 'Voicest 架构技术升级',
    modal_subtitle_info: '集成 WebTau 引擎、自动量化、Straycat 与 Rust-WORLD 语音合成 DSP',
    modal_title_shortcuts: '键盘快捷键指南',

    // Technical descriptions
    tech_quantize_title: '1. 自动吸附与微隙消除 (Auto-Quantize & Micro-Gap Elimination)',
    tech_quantize_desc: '根据所选网格（1/16、1/8、1/4、1/32、三连音）自动对齐音符起点与时长。自动缝合相邻音符缝隙，消除节拍抖动与滞后。',
    tech_legato_title: '2. 50ms 余弦 S 曲线平滑连音 (OpenUTAU / WebTau 标准)',
    tech_legato_desc: '移除旧式手动音高混合。在相邻音符交界处前后各 25ms（共 50ms）应用对称余弦 S 曲线进行平滑音高过渡。',
    tech_straycat_title: '3. Straycat-rs UTAU 标志与音素时值模型',
    tech_straycat_desc: '支持标准 UTAU 标志解析（g: 共振峰性别因子, B: 气声, t: 音高偏移, vel: 辅音速度, p: 峰值压限），精准配合 oto.ini 前置发音与重叠值。',
    tech_rustworld_title: '4. Rust-WORLD 语音 DSP（软压限与直流滤波）',
    tech_rustworld_desc: '加入 15Hz 直流滤除器与 tanh 软饱和压限器，彻底杜绝多共振峰元音合成时的爆音与破音现象。',
    tech_d3_title: '5. D3.js 实时歌声音高轨迹可视化',
    tech_d3_desc: '实时渲染合成歌声的基频 F0 轨迹，精准展示连音区域与播放光标同步状态。',

    // Shortcuts modal
    sc_space: '播放 / 暂停',
    sc_q: '按网格量化对齐音符',
    sc_tools: '选择工具 (1: 音符, 2: 调音点, 3: 画笔, 4: 橡皮擦)',
    sc_undo: '撤销',
    sc_redo: '重做',
    sc_transpose: '半音移调 (按住 Shift 移动八度)',
    sc_home: '回到开头',
    sc_note_len: '增减默认音符长度',
    sc_loop: '切换循环播放',
    sc_metro: '切换节拍器',

    // Feedback messages
    toast_quantized: '已将 {0} 个音符按 {1} 网格量化！',
    toast_legato_done: '已完美衔接 {0} 处连音！',
    toast_lang_changed: '已切换语言为 {0}',
  },
  ko: {
    // Brand & Header
    app_title: 'VOICEST v1.5x',
    engine_badge: 'WebTau 엔진 + 자동 레가토',
    minimal_mode: '미니멀 모드',

    // Quantize Controls
    quantize_btn: '퀀타이즈 (Q)',
    quantize_tooltip: '선택한 박자 그리드에 맞춰 음표 정렬 (단축키: Q)',
    legato_link_btn: '레가토 연결',
    legato_link_tooltip: '인접한 음표 사이 미세 간격을 닫아 매끄러운 레가토 전환 보장',
    auto_quantize: '자동 맞춤',
    auto_quantize_on: '켜짐',
    auto_quantize_off: '꺼짐',
    auto_quantize_tooltip: '음표 입력 시 그리드에 자동 스냅 및 레가토 간격 자동 보정',
    grid_label: '그리드',
    grid_1_16: '1/16 (기본)',
    grid_1_8: '1/8 (느림)',
    grid_1_4: '1/4 (박자)',
    grid_1_32: '1/32 (빠름)',
    grid_1_64: '1/64 (초고속)',
    grid_1_16t: '1/16T (셋잇단음표)',
    grid_1_8t: '1/8T (셋잇단음표 느림)',

    // Header Actions
    visualizer_toggle: 'F0 피치 곡선',
    visualizer_tooltip: 'D3.js 실시간 피치 곡선 시각화 켜기/끄기',
    info_btn: '업그레이드 & 기술',
    info_tooltip: 'WebTau 엔진, 자동 퀀타이즈, Straycat 및 Rust-WORLD 아키텍처 보기',
    shortcuts_btn: '단축키 안내',
    shortcuts_tooltip: '키보드 단축키 가이드 보기',
    download_btn: 'HTML 저장',
    download_tooltip: '오프라인에서 독립 구동되는 Voicest HTML 다운로드',
    reload_tooltip: '스튜디오 다시 불러오기',
    fullscreen_on: '전체 화면',
    fullscreen_off: '전체 화면 종료',
    lang_selector: '언어',

    // Pitch Visualizer
    pitch_visualizer_title: 'D3.js 보컬 피치 F0 곡선 시각화',
    track_vocal: '보컬 트랙',
    pitch_axis_label: '음높이 (MIDI Pitch)',
    time_axis_label: '시간 (초)',
    total_notes: '총 음표 수',
    total_duration: '재생 시간',
    legato_transitions: '레가토 S-Curve 구간',
    avg_pitch: '평균 피치',
    zoom_in: '확대',
    zoom_out: '축소',
    fit_zoom: '화면 맞춤',
    click_to_seek: '클릭하여 해당 위치로 탐색',
    legato_badge: '50ms S-Curve 코사인',
    transition_tooltip: '레가토 전환: {0} ➔ {1} ({2}ms)',
    note_tooltip: '음표: {0} ({1}) | {2}초 - {3}초 ({4}초)',

    // Modals
    close: '닫기',
    understood: '확인',
    modal_title_info: 'Voicest 아키텍처 업그레이드',
    modal_subtitle_info: 'WebTau 엔진, 자동 퀀타이즈, Straycat 및 Rust-WORLD 보코더 DSP 통합',
    modal_title_shortcuts: '키보드 단축키 가이드',

    // Technical descriptions
    tech_quantize_title: '1. 자동 퀀타이즈 & 미세 간격 제거 (Micro-Gap Elimination)',
    tech_quantize_desc: '지정한 그리드(1/16, 1/8, 1/4, 1/32, 셋잇단음표)에 맞춰 음표의 시작과 길이를 자동 정렬하고, 인접 음표 사이의 미세 공백을 메워 박자 밀림과 틈새를 방지합니다.',
    tech_legato_title: '2. 50ms S-Curve 레가토 연결 (OpenUTAU / WebTau 표준)',
    tech_legato_desc: '수동 피치 블렌딩을 제거하고, 음표 경계 전후 25ms(총 50ms)에 걸쳐 부드러운 코사인 S-커브로 자연스러운 글라이드를 생성합니다.',
    tech_straycat_title: '3. Straycat-rs UTAU 플래그 및 음소 모델',
    tech_straycat_desc: '표준 UTAU 플래그(g: 성별 포먼트 이동, B: 숨소리, t: 피치 변조, vel: 자음 속도) 파싱 및 oto.ini 선행 발성, 오버랩 자동 보정.',
    tech_rustworld_title: '4. Rust-WORLD 보코더 DSP (소프트 리미터 & DC 차단기)',
    tech_rustworld_desc: '15Hz DC 블로커 필터와 tanh 소프트 새츄레이션 리미터를 탑재하여 다중 포먼트 모음 합성 시의 디지털 클리핑 및 팝 노이즈를 완벽 차단합니다.',
    tech_d3_title: '5. D3.js 실시간 보컬 피치 컨투어',
    tech_d3_desc: '합성된 음성의 F0 궤적을 D3.js로 실시간 렌더링하여 레가토 구간의 부드러움을 눈으로 검증할 수 있습니다.',

    // Shortcuts modal
    sc_space: '재생 / 일시정지',
    sc_q: '그리드에 맞춰 음표 퀀타이즈',
    sc_tools: '도구 선택 (1: 음표, 2: 피치 점, 3: 브러시, 4: 지우개)',
    sc_undo: '실행 취소',
    sc_redo: '다시 실행',
    sc_transpose: '반음 조옮김 (Shift 누르고 이동 시 옥타브)',
    sc_home: '맨 앞으로 이동',
    sc_note_len: '기본 음표 길이 늘이기/줄이기',
    sc_loop: '반복 재생 켜기/끄기',
    sc_metro: '메트로놈 켜기/끄기',

    // Feedback messages
    toast_quantized: '{0}개의 음표를 {1} 그리드에 정렬했습니다!',
    toast_legato_done: '{0}개의 레가토 구간을 완벽하게 연결했습니다!',
    toast_lang_changed: '언어를 {0}(으)로 변경했습니다',
  },
};

/**
 * Format string replacing {0}, {1}, etc.
 */
export function t(key: string, lang: Language = 'vi', ...args: (string | number)[]): string {
  const dict = TRANSLATIONS[lang] || TRANSLATIONS.vi;
  let text = dict[key] || TRANSLATIONS.en[key] || key;
  if (args.length > 0) {
    text = text.replace(/\{(\d+)\}/g, (_, idx) => {
      const val = args[Number(idx)];
      return val !== undefined ? String(val) : '';
    });
  }
  return text;
}
